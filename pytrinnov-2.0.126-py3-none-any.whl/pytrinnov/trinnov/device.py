"""Module: DeviceManager."""

# pylint: disable=too-many-instance-attributes
# pylint: disable=line-too-long

import asyncio
import contextlib
import inspect
import re
from collections.abc import Callable
from functools import partial
from typing import Any

from pytrinnov.models.base import AudioSettings, DecoderBase, MachineIdentifier
from pytrinnov.models.constants import ConnectionStatus, EventType
from pytrinnov.utils.logging_utils import LoggingMixin, custom_log_pprint
from pytrinnov.utils.settings_updater import (apply_preset_list_message,
                                              apply_source_list_message)

from .commands import (CMD_GET_CURRENT_PROFILE, CMD_GET_CURRENT_STATE, CMD_ID,
                       CMD_UPMIXER)
from .config import DEFAULT_PROTOCOL_PORT
from .connection import ConnectionConfig, ConnectionManager, IPHandler
from .dispatcher import Dispatcher
from .executor import CommandExecutor
from .messages import (IGNORED_MESSAGES, Audiosync, AudiosyncStatus,
                       BassManagement, Bypass, CurrentPreset, CurrentSource,
                       CurrentSourceChannelsOrder, CurrentSourceFormatName,
                       Decoder, Dim, DisplayVolume, Error, FavLight,
                       InputConnector, ListeningFormat, MonVol, Mute,
                       NetStatus, OptimizationFlags, Preset, PresetsClear,
                       RemappingMode, Source, SourcesChanged, SourcesClear,
                       Srate, TypedResponse, Volume, VolumeOffset, Welcome)


class DeviceContext: # pylint: disable=too-few-public-methods
    """Encapsulate device state and connection management."""

    def __init__(self, reconnect: bool) -> None:
        """Initialize the DeviceContext instance."""
        self.connection = ConnectionManager(
            config=ConnectionConfig(reconnect_enabled=reconnect)
        )


class DeviceManager(LoggingMixin):
    """Manage the device's connection, state, and command execution."""

    # Mapping of class names to actual class references
    _audio_settings_classes = {
        "Audiosync": Audiosync,
        "AudiosyncStatus": AudiosyncStatus,
        "BassManagement": BassManagement,
        "Bypass": Bypass,
        "CurrentPreset": CurrentPreset,
        "CurrentSource": CurrentSource,
        "CurrentSourceChannelsOrder": CurrentSourceChannelsOrder,
        "CurrentSourceFormatName": CurrentSourceFormatName,
        "Dim": Dim,
        "DisplayVolume": DisplayVolume,
        "FavLight": FavLight,
        "InputConnector": InputConnector,
        "ListeningFormat": ListeningFormat,
        "MonVol": MonVol,
        "Mute": Mute,
        "RemappingMode": RemappingMode,
        "Srate": Srate,
        "Volume": Volume,
        "VolumeOffset": VolumeOffset,
    }

    def __init__(self, reconnect: bool = True) -> None:
        """Initialize the Device instance.

        Args:
            connection_type (str): Type of connection ("serial" or "ip").
            reconnect (bool): Whether to enable automatic reconnection on disconnection.

        """

        super().__init__()

        self.context = DeviceContext(reconnect)
        # self.context.system_state.set_update_callback(self._device_info_callback)

        self.context.connection.dispatcher.register_listener(
            EventType.CONNECTION_STATE, self._async_event_handler
        )
        self.context.connection.dispatcher.register_listener(
            EventType.DATA_RECEIVED, self._async_event_handler
        )

        self._audio_settings: AudioSettings = AudioSettings()
        self._last_response: str | None = None
        self._building_sources: bool = False
        self._building_presets: bool = False

        self._rx_queue: asyncio.Queue[Any] = asyncio.Queue()
        self._rx_consumer_started: bool = False
        self._rx_consumer_lock: asyncio.Lock = asyncio.Lock()

        """Initialize handlers dynamically."""
        self._message_handlers = {
            cls_obj: self._make_handler(self._convert_to_snake_case(cls_name))
            for cls_name, cls_obj in self._audio_settings_classes.items()
        }

        self._message_handlers[Decoder] = self._handle_decoder
        self._message_handlers[Error] = self._handle_error
        self._message_handlers[NetStatus] = self._handle_netstatus
        self._message_handlers[OptimizationFlags] = self._handle_optimization_flags
        self._message_handlers[Preset] = self._handle_preset_update
        self._message_handlers[PresetsClear] = self._handle_preset_update
        self._message_handlers[Source] = self._handle_source_update
        self._message_handlers[SourcesClear] = self._handle_source_update
        self._message_handlers[SourcesChanged] = self._handle_sources_changed
        self._message_handlers[Welcome] = self._handle_welcome


    @property
    def dispatcher(self) -> Dispatcher:
        """Dispatcher."""
        return self.context.connection.dispatcher

    @property
    def executor(self) -> CommandExecutor:
        """Expose the CommandExecutor instance."""
        if self.context.connection.executor is None:
            raise RuntimeError(
                "CommandExecutor is not initialized. Ensure `open()` is called first."
            )
        return self.context.connection.executor

    @property
    def audio_settings(self) -> AudioSettings:
        """Expose the Audio Settings."""
        return self._audio_settings

    async def open(self, **kwargs) -> None:
        """Open a connection based on the connection type.

        For serial:
            kwargs: port (str), baudrate (int)
        For IP:
            kwargs: host (str), port (int)
        """
        try:
            self.context.connection.config.connection_params = kwargs.copy()

            self.context.connection.handler = await self._init_ip_handler(**kwargs)
            self.context.connection.executor = CommandExecutor(
                self.context.connection.handler, self
            )
            self.log.info("Connection opened successfully")

        except ValueError as e:
            self.log.error("Failed to open connection: %s", e)
            raise

    async def close(self) -> None:
        """Close the connection and cancel all managed tasks safely."""

        if self.context.connection.closing:
            self.log.info("Close operation already in progress.")
            return

        self.context.connection.closing = True
        self.log.info("Closing device connection...")

        try:
            if self.context.connection.handler:
                try:
                    await self.context.connection.handler.close()
                except (ConnectionError, asyncio.exceptions.TimeoutError, OSError) as e:
                    self.log_error("Error while closing connection handler: %s", e)
                finally:
                    self.context.connection.handler = None

            with contextlib.suppress(asyncio.CancelledError):
                await self.context.connection.task_manager.cancel_task("rx_consumer")

            with contextlib.suppress(asyncio.CancelledError):
                await self.context.connection.task_manager.cancel_all_tasks()

            self._rx_consumer_started = False
            self._rx_queue = asyncio.Queue()

            self.context.connection.config.status = ConnectionStatus.DISCONNECTED

        finally:
            self.context.connection.closing = False

    async def send_command(self, command: str | list[str]) -> None:
        """Send a command to the device via the CommandExecutor."""
        return await self.context.connection.executor.send_command(command)

    async def _init_ip_handler(self, host: str, port: int | None = None) -> IPHandler:
        """Initialize an IP connection with a default port if none is provided."""

        if not host:
            raise ValueError("Host must be provided for IP connection")

        if port is None:
            port = DEFAULT_PROTOCOL_PORT

        self.log.info("Opening IP connection to %s:%d", host, port)

        ip_handler = IPHandler(self.context.connection.dispatcher)
        await ip_handler.open_connection(host, port)

        return ip_handler

    async def _ensure_rx_consumer(self) -> None:
        """Ensure the DATA_RECEIVED consumer task is running.

        We intentionally process all inbound responses sequentially to avoid
        dropping messages and to preserve protocol ordering.
        """

        async with self._rx_consumer_lock:
            if self._rx_consumer_started:
                return
            self._rx_consumer_started = True

        async def _consumer() -> None:
            while True:
                response = await self._rx_queue.get()
                try:
                    await self._handle_data_received(response)
                finally:
                    self._rx_queue.task_done()

        self.context.connection.task_manager.add_task(_consumer, name="rx_consumer")

    async def _async_event_handler(
        self, event_type: EventType, event_data: dict
    ) -> None:
        """Handle events from the connection handler."""

        if not isinstance(event_type, EventType):
            self.log.error("Invalid event type received: %s", event_type)
            return

        match event_type:
            case EventType.CONNECTION_STATE:
                state = event_data.get("state")

                self.log.debug("Received connection state event: %s", state)

                if state is None:
                    self.log.error("Missing 'state' key in event_data: %s", event_data)
                    return

                try:
                    self.context.connection.config.status = ConnectionStatus(state)
                    self.log.info(
                        "Updated connection status: %s",
                        self.context.connection.config.status.name,
                    )
                except ValueError:
                    self.log.error(
                        "Invalid connection state received: %s. Defaulting to DISCONNECTED.",
                        state,
                    )
                    self.context.connection.config.status = ConnectionStatus.DISCONNECTED

                if self.context.connection.config.status == ConnectionStatus.CONNECTED:
                    self.log.info("Device connected.")
                    await self.context.connection.task_manager.cancel_task("reconnect_loop")

                elif self.context.connection.config.status == ConnectionStatus.DISCONNECTED:
                    self.context.connection.handler = None
                    self.log.warning("Connection lost. is_connected set to False.")

            case EventType.DATA_RECEIVED:
                response = event_data.get("response")

                # Better debug info for this event type
                response_name = getattr(response, "name", type(response).__name__) if response is not None else None
                self.log.debug("Data received: %s", response_name)

                if response is None:
                    self.log.error("Missing 'response' key in event_data: %s", event_data)
                    return

                # Queue inbound responses; a single consumer processes them sequentially.
                await self._ensure_rx_consumer()
                self._rx_queue.put_nowait(response)

    async def _handle_data_received(self, response: Any) -> None:
        """Handle responses received from the hardware."""

        response_name = getattr(response, "name", type(response).__name__)
        self.log.debug("Handling received response: %s", response_name)

        try:
            handler = self._get_message_handler(response, response_name)

            if not handler:
                return

            if not callable(handler):
                self.log_error("Invalid handler for %s: %s", response_name, handler)
                return

            if inspect.iscoroutinefunction(handler):
                await handler(response)
            else:
                handler(response)

            if (
                self._building_sources
                and self._last_response == "SOURCE"
                and response_name != "SOURCE"
            ):
                await self.context.connection.dispatcher.invoke_event(
                    EventType.SOURCE_LIST,
                    value=self._audio_settings.source_list,
                )
                self._building_sources = False

            if (
                self._building_presets
                and self._last_response == "PRESET"
                and response_name != "PRESET"
            ):
                await self.context.connection.dispatcher.invoke_event(
                    EventType.PRESET_LIST,
                    value=self._audio_settings.preset_list,
                )
                self._building_presets = False

            self._last_response = response_name

        except Exception as e:
            self.log_critical("Error while handling %s: %s", response_name, e)
            raise

    def _make_handler(self, state_attr: str) -> Callable[[Any], Any]:
        """Create partial functions for audio settings."""
        return partial(self._handle_audio_settings, state_attr=state_attr)

    def _convert_to_snake_case(self, name: str) -> str:
        """Convert CamelCase class names to snake_case for attribute names."""
        return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()

    def _invoke_event_singleflight(self, event_name: str, **event_data) -> None:
        """Schedule invoke_event coalesced per event_name (no drops; rerun once)."""
        self.context.connection.task_manager.add_task_singleflight(
            lambda: self.context.connection.dispatcher.invoke_event(event_name, **event_data),
            name=f"invoke_event:{event_name}",
        )

    def _get_message_handler(
        self, response: Any, response_name: str
    ) -> Callable[[Any], Any] | None:
        """Retrieve the appropriate handler for a given response object."""

        handler = self._message_handlers.get(type(response))

        if handler is None:
            if any(response_name.startswith(prefix) for prefix in IGNORED_MESSAGES):
                self.log.debug("Ignored known but unhandled message: %s", response_name)
            else:
                self.log.warning("Unhandled and unknown message: %s", response_name)

        return handler

    async def _handle_audio_settings(
        self, response: TypedResponse, state_attr: str
    ) -> None:
        """Handle updates for Audio Settings."""

        if state_attr in self._audio_settings.model_fields:
            self._audio_settings = self._audio_settings.update(
                **{state_attr: response.field}
            )
        else:
            raise ValueError(f"Invalid state attribute: {state_attr}")

        self._invoke_event_singleflight(state_attr, value=response.field)

        custom_log_pprint(
            self._audio_settings.model_dump(exclude_unset=False),
            self.log.debug,
        )

    async def _handle_decoder(self, response: DecoderBase) -> None:
        """Handle updates for Decoder Message."""

        if not isinstance(response, DecoderBase):
            self.log.error(
                "Invalid response type for Decoder Message: %s",
                type(response).__name__,
            )
            return

        self._audio_settings = self._audio_settings.update(
            decoder_nonaudio=response.nonaudio,
            decoder_playable=response.playable,
            decoder_decoder=str(response.decoder),
            decoder_upmixer=str(response.upmixer)
        )

        self._invoke_event_singleflight("decoder_playable", value=self._audio_settings.decoder_playable)
        self._invoke_event_singleflight("decoder_decoder", value=self._audio_settings.decoder_decoder)
        self._invoke_event_singleflight("decoder_upmixer", value=self._audio_settings.decoder_upmixer)

        custom_log_pprint(
            response.model_dump(),
            self.log.debug,
        )

    async def _handle_error(self, response: Error) -> None:
        """Handle updates for Error Message."""

        if not isinstance(response, Error):
            self.log.error(
                "Invalid response type for Error Message: %s",
                type(response).__name__,
            )
            return
        self.log.error("Received Error Message from the Device: %s", response.fields[0])

    async def _handle_netstatus(self, response: NetStatus) -> None:
        """Handle updates for Netstatus Message."""

        if not isinstance(response, NetStatus):
            self.log.error(
                "Invalid response type for Netstatus Message: %s",
                type(response).__name__,
            )
            return

        custom_log_pprint(
            response.model_dump(),
            self.log.debug,
        )

    async def _handle_welcome(self, response: MachineIdentifier) -> None:
        """Handle updates for Welcome Message."""

        if not isinstance(response, MachineIdentifier):
            self.log.error(
                "Invalid response type for Welcome Message: %s",
                type(response).__name__,
            )
            return

        custom_log_pprint(
            response.model_dump(),
            self.log.info,
        )
        await self.send_command(f"{CMD_ID}")
        await self.send_command(f"{CMD_GET_CURRENT_STATE}")

    async def _handle_optimization_flags(self, response: OptimizationFlags) -> None:
        """Handle OPTIMIZATION flags message."""
        self._audio_settings = self._audio_settings.update(optimization=response)
        custom_log_pprint({"optimization_flags": response.model_dump()}, self.log.info)

    async def _handle_preset_update(self, response: Preset | PresetsClear) -> None:
        """Handle PRESET and PRESETS_CLEAR messages."""
        self._audio_settings = apply_preset_list_message(self._audio_settings, response)

        if isinstance(response, PresetsClear):
            self._building_presets = True
            await self.context.connection.dispatcher.invoke_event(EventType.PRESET_LIST, value={})

    async def _handle_source_update(self, response: Source | SourcesClear) -> None:
        """Handle SOURCE and SOURCES_CLEAR messages."""
        self._audio_settings = apply_source_list_message(self._audio_settings, response)

        if isinstance(response, SourcesClear):
            self._building_sources = True
            await self.context.connection.dispatcher.invoke_event(EventType.SOURCE_LIST, value={})

    async def _handle_sources_changed(self, _: SourcesChanged) -> None:
        """Handle function for Sources Changed messages."""
        await self.send_command(f"{CMD_GET_CURRENT_PROFILE}")
        await self.send_command(f"{CMD_UPMIXER}")

    async def show_audio_settings(self) -> None:
        """Show Audio Settings."""
        custom_log_pprint(
            self._audio_settings.model_dump(exclude_unset=False),
            self.log.info,
        )

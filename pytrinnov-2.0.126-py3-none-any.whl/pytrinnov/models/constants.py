"""Constants."""

from enum import Enum


class ConnectionStatus(Enum):
    """Enum for connection statuses."""

    CONNECTED = "connected"
    DISCONNECTED = "disconnected"


class EventType(Enum):
    """Enum for valid event types."""

    CONNECTION_STATE = "connection_state"
    DATA_RECEIVED = "data_received"
    STATE_CHANGED = "state_changed"
    SOURCE_LIST = "source_list"
    PRESET_LIST = "preset_list"


# WebSocket API Endpoints
WS_ETHERNET = "/system/network/ethernet"
WS_CONFIG = "/config"
WS_UPDATES = "/system/updates"

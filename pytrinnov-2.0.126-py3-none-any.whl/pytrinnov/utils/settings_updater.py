"""Helpers for applying incoming Trinnov messages to update client-side settings.

This module provides functions to incrementally update fields in the AudioSettings model
based on parsed protocol messages like PRESET, PROFILE, PRESETS_CLEAR, and PROFILES_CLEAR.

It is designed to avoid circular imports between the core models and message parsing logic.
"""

from pytrinnov.models.base import AudioSettings
from pytrinnov.trinnov.messages import (Preset, PresetsClear, Source,
                                        SourcesClear)


def _apply_indexed_update(
    settings: AudioSettings, message, *, clear_cls, update_cls, field_name: str
) -> AudioSettings:
    """Handle indexed key-value messages like PRESET and PROFILE."""

    if isinstance(message, clear_cls):
        return settings.update(**{field_name: {}})

    if isinstance(message, update_cls):
        fields = message.fields
        if len(fields) >= 2:
            key_part, *value_parts = fields
            if key_part.endswith(":"):
                try:
                    index = int(key_part.rstrip(":"))
                    value = " ".join(value_parts).strip()
                    current = getattr(settings, field_name)
                    return settings.update(**{field_name: {**current, index: value}})
                except ValueError:
                    pass

    return settings


def apply_indexed_list_message(
    settings: AudioSettings,
    message,
    *,
    clear_cls: type,
    update_cls: type,
    field_name: str,
) -> AudioSettings:
    """Apply indexed update messages (CLEAR or item update) to an AudioSettings list field."""

    return _apply_indexed_update(
        settings,
        message,
        clear_cls=clear_cls,
        update_cls=update_cls,
        field_name=field_name,
    )


def apply_preset_list_message(settings: AudioSettings, message) -> AudioSettings:
    """Apply PRESET or PRESETS_CLEAR messages."""
    return apply_indexed_list_message(
        settings,
        message,
        clear_cls=PresetsClear,
        update_cls=Preset,
        field_name="preset_list",
    )


def apply_source_list_message(settings: AudioSettings, message) -> AudioSettings:
    """Apply SOURCE or SOURCES_CLEAR messages."""
    return apply_indexed_list_message(
        settings,
        message,
        clear_cls=SourcesClear,
        update_cls=Source,
        field_name="source_list",
    )



"""Task Manager."""

import asyncio
import inspect
from collections.abc import Callable, Coroutine
from typing import Any

from .logging_utils import LoggingMixin


class TaskManager(LoggingMixin):
    """Manage and track multiple asyncio tasks safely."""

    def __init__(self) -> None:
        """Initialize the task manager with an empty dictionary of tasks."""
        super().__init__()
        self.active_tasks: dict[str, asyncio.Task] = {}
        self._singleflight: dict[str, dict[str, Any]] = {}

    def add_task(self, coro_or_callable, name: str) -> asyncio.Task | None:
        """Add a coroutine task by name. Skip if task is already active.

        Accepts either:
        - a coroutine object (already created)
        - a callable (e.g. lambda) that returns a coroutine
        """

        if not isinstance(name, str):
            raise TypeError(f"Task name must be a string, got {type(name).__name__}")

        if name in self.active_tasks:
            self.log.warning("Task '%s' is already running. Skipping duplicate.", name)
            if inspect.iscoroutine(coro_or_callable):
                coro_or_callable.close()
            return self.active_tasks[name]

        # If a callable (like lambda), call it to create the coroutine
        coro = coro_or_callable() if callable(coro_or_callable) else coro_or_callable

        task = asyncio.create_task(coro, name=name)
        task.add_done_callback(lambda t: self._handle_task_completion(t, name))
        self.active_tasks[name] = task
        return task

    def add_task_singleflight(
        self,
        coro_factory: Callable[[], Coroutine[Any, Any, Any]],
        name: str,
    ) -> asyncio.Task:
        """Run at most one task per name; if triggered while running, rerun once after completion.

        Use this for coalescable work (e.g. "invoke_event"): bursts collapse into
        one extra run instead of being dropped.
        """
        if not isinstance(name, str):
            raise TypeError(f"Task name must be a string, got {type(name).__name__}")

        slot = self._singleflight.get(name)
        if slot is None:
            slot = {"lock": asyncio.Lock(), "rerun": False}
            self._singleflight[name] = slot

        existing = self.active_tasks.get(name)
        if existing and not existing.done():
            slot["rerun"] = True
            return existing

        async def _runner() -> None:
            async with slot["lock"]:
                while True:
                    slot["rerun"] = False
                    await coro_factory()
                    if not slot["rerun"]:
                        return

        task = asyncio.create_task(_runner(), name=name)
        task.add_done_callback(lambda t: self._handle_task_completion(t, name))
        self.active_tasks[name] = task
        return task

    def _handle_task_completion(self, task: asyncio.Task, name: str) -> None:
        """Remove completed tasks and log any errors or cancellations."""
        self.active_tasks.pop(name, None)

        if task.cancelled():
            self.log.info("Task '%s' was cancelled.", name)
        elif task.exception():
            self.log.error("Task '%s' raised an exception: %s", name, task.exception())

    async def cancel_task(self, name: str) -> None:
        """Cancel a specific task by name."""
        task = self.active_tasks.pop(name, None)

        if not task:
            return

        self.log.info("Cancelling task: %s", name)
        task.cancel()

        try:
            await task
        except asyncio.CancelledError:
            self.log.info("Task '%s' was successfully cancelled.", name)
            raise

    async def cancel_all_tasks(self) -> None:
        """Cancel all tasks managed by the TaskManager."""

        # Log the caller module, class, and function.
        stack = inspect.stack()[1]
        caller_module = inspect.getmodule(stack.frame).__name__.split(".")[1]
        caller_class = (
            stack.frame.f_locals["self"].__class__.__name__
            if "self" in stack.frame.f_locals
            else "Unknown"
        )

        caller_function = stack.function

        self.log.info(
            "TaskManager.cancel_all_tasks() called by: %s.%s.%s",
            caller_module,
            caller_class,
            caller_function,
        )

        for task in self.active_tasks.values():
            task.cancel()

        results = await asyncio.gather(
            *self.active_tasks.values(), return_exceptions=True
        )

        self.active_tasks.clear()

        self.log.info("All tasks have been cancelled and cleared.")

        for result in results:
            if isinstance(result, asyncio.CancelledError):
                raise result

    async def wait_for_all_tasks(self) -> None:
        """Wait for the completion of all managed tasks."""
        if self.active_tasks:
            await asyncio.gather(*self.active_tasks.values(), return_exceptions=True)

    def get_task(self, name: str) -> asyncio.Task | None:
        """Check if a task with a given name is currently running."""
        return self.active_tasks.get(name)

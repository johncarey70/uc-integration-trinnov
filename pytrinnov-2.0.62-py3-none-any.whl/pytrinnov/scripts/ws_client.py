#!/usr/bin/env python3

"""Trinnov WebSocket Client."""

import asyncio
import logging
import sys

from pytrinnov.models.base import (ConfigStatus, EthernetStatus,
                                   SystemUpdateStatus)
from pytrinnov.models.constants import WS_CONFIG, WS_ETHERNET, WS_UPDATES
from pytrinnov.trinnov.websocket import DeviceError, WebSocketClient
from pytrinnov.utils.logging_utils import custom_log_pprint

# Configure logging
logging.basicConfig(level=logging.INFO)
_LOGGER = logging.getLogger(__name__)


async def main():
    """Send WebSocket messages and process responses."""
    host = sys.argv[1] if len(sys.argv) > 1 else "trinnov.local.lan"

    try:
        async with WebSocketClient(host) as client:
            responses = await client.send_and_receive(
                [
                    (WS_ETHERNET, 1, None),
                    (WS_CONFIG, 1, None),
                    (WS_UPDATES, 1, None),
                ]
            )

            # Validate responses with Pydantic models
            ethernet_status = EthernetStatus.model_validate(responses[WS_ETHERNET])
            config_status = ConfigStatus.model_validate(responses[WS_CONFIG])
            update_status = SystemUpdateStatus.model_validate(responses[WS_UPDATES])

            # Print structured response data
            # print("Ethernet MAC Address:", ethernet_status.macaddr)
            # print("Config Status Serial Number:", config_status.serial)
            # print("Update Status Available Release:", update_status.available_release)

            custom_log_pprint(ethernet_status.model_dump(), print)
            custom_log_pprint(config_status.model_dump(), print)
            custom_log_pprint(update_status.model_dump(), print)

    except DeviceError as exc:
        _LOGGER.error("WebSocket error: %s", exc)
        _LOGGER.info("Check if the device is powered on and accessible")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

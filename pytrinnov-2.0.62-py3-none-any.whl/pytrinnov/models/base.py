"""Data Models and Enumerations for the Device."""

from enum import IntEnum
from typing import Literal

from pydantic import (BaseModel, Field, IPvAnyAddress, field_serializer,
                      field_validator)


class GenericResponseModel(BaseModel):
    """Fallback model for unrecognized WebSocket responses."""

    raw_data: dict


class EthernetStatus(BaseModel):
    """Model for `/system/network/ethernet` response."""

    connected: bool
    dhcp: bool
    gateway: str
    ip: str
    macaddr: str
    netmask: str
    status_name: str


class SetupConfig(BaseModel):
    """Nested model for setup data in `/config` response."""

    cinema: int
    dmon: int
    hifi: int
    home_cinema: int
    jbl_sdp: int
    logo: str
    microphones_display: str
    no_analog_192: int
    no_clock_from_tac: int
    ovation_x: int
    require_composition_match: int
    with_buffer_size_4096: int
    with_delay_lines: int
    with_light_mode: int
    with_master_192: int
    with_soft_bypass: int


class ConfigStatus(BaseModel):
    """Model for `/config` response."""

    class_: int = Field(..., alias="class")  # Fixing reserved keyword
    class_name: str
    class_shortname: str
    copyright: int
    display_compile_date_time: str
    display_product_id: str
    display_release: str
    gcc_version: str
    gtp_compile_date: str
    gtp_compile_time: str
    gtp_release: str
    gtp_version: str
    idents: list[str]
    ident_str: str
    info: str
    licence: int
    licence_extraways: int
    licence_input: int
    lib3dsp_compile_date: str
    lib3dsp_compile_time: str
    lib3dsp_release: str
    lib3dsp_version: str
    optimizer_compile_date: str
    optimizer_compile_time: str
    optimizer_microphone: str
    optimizer_release: str
    optimizer_version: str
    product_id: int
    program_name: str
    release: str
    runtime_mode: str
    runtime_mode_status: str
    serial: int
    setup: SetupConfig
    version: str


class SystemUpdateStatus(BaseModel):
    """Model for `/system/updates` response."""

    auto_update: bool
    available_release: str
    custom_text_info: str | None = None
    enabled: bool
    last_check: int
    refresh: int
    registered: bool
    release_note: str | None = None
    status: str
    update_available: bool
    updating: bool

    def formatted_release_notes(self) -> list[str]:
        """Format the release notes into a list."""
        if self.release_note:
            return [
                note.strip() for note in self.release_note.split(";\n") if note.strip()
            ]
        return []


class ModelType(IntEnum):
    """Enumeration of machine model types by ID."""
    AMETHYST = 8
    OVATION = 9
    ALTITUDE_32 = 10
    ALTITUDE_16 = 14


class MachineIdentifier(BaseModel):
    """MachineIdentifier Model."""

    firmware_version: str = Field(
        ..., alias="field.0", description="Firmware version of the machine"
    )
    srpid: int = Field(..., alias="field.1", description="System identifier (SRPID)")
    serial_number: str = Field(..., alias="field.2", description="Serial Number")
    model_name: ModelType = Field(..., alias="field.3")

    model_config = {
        "populate_by_name": True,
    }

    @field_serializer("model_name")
    def serialize_model_name(self, value: ModelType, _info):
        """Serialize the `model_name` enum as its name."""
        return value.name


# Define the upmixers dictionary
upmixers = {
    "auto": "Auto",
    "dolby": "Dolby Surround",
    "dts": "Neural:X",
    "auro3d": "Auro-3D",
    "native": "Native",
    "upmix_on_native": "Upmix on Native",
    "legacy": "Legacy",
}


class OptimizationFlagsModel(BaseModel):
    """Represents optimization flags with human-readable values."""

    state: str = Field("Unknown", alias="field.0")
    correction: str = Field("Unknown", alias="field.1")
    level_alignment: str = Field("Unknown", alias="field.2")
    time_alignment: str = Field("Unknown", alias="field.3")

    model_config = {"populate_by_name": True}

    @field_validator(
        "state", "correction", "level_alignment", "time_alignment", mode="before"
    )
    @classmethod
    def convert_to_label(cls, v: str | None) -> str:
        """Convert '1' to 'Enabled', '0' to 'Disabled', or fallback to 'Unknown'."""
        match v:
            case "1":
                return "Enabled"
            case "0":
                return "Disabled"
            case _:
                return "Unknown"


class AudioSettings(BaseModel):
    """Represents audio settings."""

    audiosync: str = ""
    audiosync_status: bool | None = None
    bypass: bool = False
    current_preset: str = ""
    current_profile: int = 0
    current_source: int = 0
    current_source_channels_order: str = ""
    current_source_format_name: str = ""
    decoder_nonaudio: str = ""
    decoder_playable: str = ""
    decoder_decoder: str = ""
    decoder_upmixer: str = ""
    display_volume: float = 0.0
    dim: bool = False
    fav_light: bool = False
    labels: dict[int, str] = Field(default_factory=dict)
    input_connector: str = ""
    mon_vol: float = 0.0
    mute: bool = False
    optimization: OptimizationFlagsModel = Field(default_factory=OptimizationFlagsModel)
    profile: str = ""
    profiles: dict[int, str] = Field(default_factory=dict)
    sound_mode_list: dict[str, str] = Field(default_factory=lambda: upmixers)
    remapping_mode: str = ""
    srate: float = 0.0
    upmixer: str = ""
    volume: float = 0.0
    volume_offset: float = 0.0

    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}

    def clear_labels(self) -> "AudioSettings":
        """Return a new instance with labels cleared."""
        return self.update(labels={})

    def add_label(self, index: int, label: str) -> "AudioSettings":
        """Return a new instance with a single label added."""
        return self.update(labels={**self.labels, index: label})

    def update(self, **kwargs) -> "AudioSettings":
        """Return a new instance with updated fields."""
        return self.model_copy(update=kwargs)


class DecoderBase(BaseModel):
    """Pydantic v2 model for Decoder message."""

    nonaudio: str = Field(..., alias="field.0")
    playable: bool = Field(..., alias="field.1")
    decoder: str = Field(..., alias="field.2")
    upmixer: str = Field(..., alias="field.3")

    model_config = {
        "populate_by_name": True,
    }


class NetstatusEth(BaseModel):
    """Represents NETSTATUS message for Ethernet (ETH) connection."""

    type: Literal["ETH"]
    link: str = Field(..., alias="field.0")
    dhcp: bool = Field(..., alias="field.1")
    ip: IPvAnyAddress = Field(..., alias="field.2")
    netmask: IPvAnyAddress = Field(..., alias="field.3")
    gateway: IPvAnyAddress = Field(..., alias="field.4")
    dns: IPvAnyAddress = Field(..., alias="field.5")


class NetstatusWlan(BaseModel):
    """Represents NETSTATUS message for Wireless (WLAN) connection."""

    type: Literal["WLAN"]
    wlanmode: str = Field(..., alias="field.0")
    link: str = Field(..., alias="field.1")
    ssid: str = Field(..., alias="field.2")
    ap_ssid: str = Field(..., alias="field.3")
    ap_password: str = Field(..., alias="field.4")
    ap_ip: IPvAnyAddress = Field(..., alias="field.5")
    ap_netmask: IPvAnyAddress = Field(..., alias="field.6")
    ip: IPvAnyAddress = Field(..., alias="field.7")
    netmask: IPvAnyAddress = Field(..., alias="field.8")
    wpa_state: str = Field(..., alias="field.9")


class NetstatusService(BaseModel):
    """Represents NETSTATUS message for SERVICE_STATUS."""

    type: Literal["SERVICE"]
    status: str = Field(..., alias="field.0")

    model_config = {
        "populate_by_name": True,
    }


NetstatusModel = NetstatusEth | NetstatusWlan | NetstatusService

"""Configuration settings for the Lumagen package."""

# Default communication settings
DEFAULT_BUFFER_SIZE = 1024
DEFAULT_PROTOCOL_PORT = 44100
DEFAULT_COMMAND_TIMEOUT = 5

"""A python client library for controlling a Trinnov Altitude Processor."""

__version__ = "2.0.62"

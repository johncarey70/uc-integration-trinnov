"""Handles serial and IP communication using asyncio."""

from __future__ import annotations

import asyncio
import contextlib
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from pytrinnov.models.constants import ConnectionStatus, EventType
from pytrinnov.utils.logging_utils import LoggingMixin
from pytrinnov.utils.task_manager import TaskManager

from .commands import CMD_ACK, CMD_TERMINATOR
from .config import DEFAULT_COMMAND_TIMEOUT
from .dispatcher import Dispatcher
from .messages import Response

if TYPE_CHECKING:  # pragma: no cover
    from .executor import CommandExecutor


class BufferManager:
    """Manage a data buffer in a streaming context.

    This class provides utility methods for handling a buffer, extracting messages,
    and checking for specific conditions like prefixes or terminators.
    """

    def __init__(self, terminator: str = "\n", ignored_prefixes: tuple = ()) -> None:
        r"""Initialize the buffer manager with a terminator and ignored prefixes.

        Args:
            terminator (str): The character or string that marks the end of a message.
                              Defaults to "\n".
            ignored_prefixes (tuple): A tuple of prefixes to ignore in the buffer.
                                      Defaults to an empty tuple.

        """
        self.terminator = terminator
        self.ignored_prefixes = ignored_prefixes
        self.buffer = ""

    def append(self, data: str) -> None:
        """Append data to the buffer.

        Args:
            data (str): The data to append to the buffer.

        """
        self.buffer += data

    def extract_message(self) -> str:
        """Extract a complete message from the buffer and update the buffer.

        Removes the message if it ends with the terminator.

        Returns:
            str: The extracted message with leading and trailing whitespace stripped.
                 Returns an empty string if no complete message is available.

        """
        end_idx = self.buffer.find(self.terminator) + len(self.terminator)
        if end_idx > 0:
            message = self.buffer[:end_idx]
            self.buffer = self.buffer[end_idx:]
            return message.strip()
        return ""

    def clear(self) -> None:
        """Clear the buffer by removing all its contents."""
        self.buffer = ""

    def starts_with(self, prefixes: tuple) -> bool:
        """Check if the buffer starts with any of the specified prefixes.

        Args:
            prefixes (tuple): A tuple of prefixes to check.

        Returns:
            bool: True if the buffer starts with one of the prefixes, False otherwise.

        """
        return self.buffer.lower().startswith(
            tuple(prefix.lower() for prefix in prefixes)
        )

    def ends_with_terminator(self) -> bool:
        """Check if the buffer ends with the terminator.

        Returns:
            bool: True if the buffer ends with the terminator, False otherwise.

        """
        return self.buffer.endswith(self.terminator)

    def is_empty(self) -> bool:
        """Check if the buffer is empty or contains only whitespace.

        Returns:
            bool: True if the buffer is empty or contains only whitespace, False otherwise.

        """
        return not self.buffer.strip()

    def adjust_buffer(self, keywords: list[str]) -> None:
        """Modify the buffer to start from the first detected keyword."""
        buffer_lower = self.buffer.lower()
        for keyword in keywords:
            start_idx = buffer_lower.find(keyword.lower())

            if start_idx != -1:
                # Special case: If buffer is exactly "#!", do not modify it
                if (
                    keyword == "!"
                    and start_idx == 1
                    and self.buffer[start_idx - 1] == "#"
                    and len(self.buffer) == 2
                ):
                    return

                # Adjust the buffer to start from the keyword
                self.buffer = self.buffer[start_idx:]
                return


@dataclass
class ConnectionConfig:
    """Holds connection settings and parameters."""

    status: ConnectionStatus = ConnectionStatus.DISCONNECTED
    reconnect_enabled: bool = True
    connection_params: dict[str, Any] = field(default_factory=dict)


class ConnectionState(LoggingMixin): # pylint: disable=too-many-instance-attributes
    """Encapsulates the state of the connection for serial and IP communication.

    Provides utility methods for managing the connection state, including
    buffering data, managing command queues, and tracking responses.
    """

    def __init__(self) -> None:
        """Initialize a new ConnectionState instance.

        Attributes:
            buffer (deque[str]): Stores incoming data.
            command_queue (deque): Holds commands to be sent.
            command_response_map (dict[str, str]): Maps commands to their expected responses.
            last_command_byte (str): Stores the last byte of the last command sent.
            sending_command (bool): Tracks whether a command is currently being sent.
            current_command (Optional[str]): Stores the current command being processed.

        """
        super().__init__()
        self.buffer: deque[str] = deque()
        self.command_queue = deque()
        self.command_response_map: dict[str, str] = {}
        self.last_command_byte: str = ""
        self.sending_command: bool = False
        self.current_command: str | None = None
        self.power_changing: bool = False
        self.processing_message: bool = False

    def append_to_buffer(self, data: str) -> None:
        """Append data to the buffer.

        Args:
            data (str): The data to append to the buffer.

        """
        self.buffer.extend(data)

    def clear_buffer(self) -> None:
        """Clear the communication buffer."""
        self.buffer.clear()

    def has_pending_commands(self) -> bool:
        """Check if there are commands in the queue.

        Returns:
            bool: True if the command queue is not empty, False otherwise.

        """
        if not self.command_queue:
            self.current_command = None
        return bool(self.command_queue)

    def pop_next_command(self) -> str | None:
        """Retrieve the next command from the queue and update the current command."""
        if self.command_queue:
            self.current_command = self.command_queue.popleft()
            self.log.debug("Commands remaining in queue: %d", len(self.command_queue))
            return self.current_command
        self.log.debug("Queue is empty after pop attempt")
        self.current_command = None
        return None


@dataclass
class ConnectionManager:
    """Manages the connection state and communication handlers for the device."""

    config: ConnectionConfig = field(default_factory=ConnectionConfig)
    handler: IPHandler = None
    task_manager: TaskManager = field(default_factory=TaskManager)
    dispatcher: Dispatcher = field(default_factory=Dispatcher)
    executor: CommandExecutor = None
    closing: bool = False


class BaseHandler(LoggingMixin):
    """Base handler for managing shared connection logic."""

    def __init__(self, dispatcher: Dispatcher | None = None) -> None:
        """Initialize with common configuration and event callback."""
        super().__init__()
        self._dispatcher: Dispatcher = dispatcher
        self._task_manager = TaskManager()
        self.connection_state = ConnectionState()
        self._state_lock = asyncio.Lock()
        self.reader: asyncio.StreamReader = None
        self.writer: asyncio.StreamWriter = None
        self._ok_received = asyncio.Event()

    async def process_stream(self):
        """Process incoming data stream."""

        buffer_manager = BufferManager(terminator="\n")

        async def process_message() -> None:
            """Process a single message from the buffer."""
            message = buffer_manager.extract_message()
            if message:
                self.log.debug("Processing Message: %s", message)

                if message == CMD_ACK:
                    self._ok_received.set()
                    return
                if message.startswith("IDENTS"):
                    return

                try:
                    response = Response.factory(message)

                    await self._dispatcher.invoke_event(
                        EventType.DATA_RECEIVED,
                        response=response,
                        message=response.name,
                    )
                except ValueError as ex:
                    self.log.error(ex)
            self.connection_state.processing_message = False
            self.process_next_command()

        async def process_buffer() -> bool:
            """Process the buffer and return whether to continue the loop."""
            if buffer_manager.is_empty():
                buffer_manager.clear()
                return False

            self.connection_state.processing_message = True
            self.log.debug("Buffer updated: %s", buffer_manager.buffer.encode())

            await process_message()
            return True

        while True:
            await asyncio.sleep(0)  # allow cancel task
            try:
                result = await self._read_single_byte(buffer_manager)
                if not result:
                    self.log.info("Stream terminated, exiting stream processing loop.")
                    self._task_manager.add_task(
                        self._dispatcher.invoke_event(
                            EventType.CONNECTION_STATE,
                            state=ConnectionStatus.DISCONNECTED,
                        ),
                        "invoke_event",
                    )

                    break

                data = await self._read_additional_data()
                if data:
                    buffer_manager.append(data)

                if not await process_buffer():
                    continue

            except asyncio.CancelledError:
                self.log.debug("Task process_message cancelled.")
                raise

    async def _read_single_byte(self, buffer_manager: BufferManager) -> bool:
        """Read a single byte and append it to the buffer."""
        single_byte = await self.reader.read(1)
        if not single_byte:
            self.log.info("Stream ended (connection closed)")
            return False

        buffer_manager.append(single_byte.decode("utf-8"))
        return True

    async def _read_additional_data(self) -> str:
        """Read additional data from the stream with timeout."""
        for read_func in [
            lambda: self.reader.readuntil(separator=b"\n"),
            lambda: self.reader.read(1024),
        ]:
            try:
                data: bytes = await asyncio.wait_for(read_func(), timeout=0.2)
                return data.decode("utf-8") if data else ""
            except asyncio.exceptions.TimeoutError:
                continue
        return ""

    async def send(self, data: bytes):
        """Abstract method for sending data over the connection."""
        raise NotImplementedError("send method must be implemented by subclasses")

    async def queue_command(self, command: str | list[str]):
        """Queue a command or multiple commands to be sent over an active connection."""

        if isinstance(command, str):
            command = [command]  # Convert single command to a list

        if not isinstance(command, list):
            self.log.error("Invalid command type: %s", type(command).__name__)
            return

        valid_commands = [
            cmd.strip() for cmd in command if isinstance(cmd, str) and cmd.strip()
        ]
        if not valid_commands:
            self.log.error("No valid commands to queue.")
            return

        self.connection_state.command_queue.extend(valid_commands)
        self.log.debug(
            "Queued %d commands. Commands remaining: %d",
            len(valid_commands),
            len(self.connection_state.command_queue),
        )

        self.process_next_command()

    def process_next_command(self):
        """Trigger processing of the next command in the queue."""
        if not self._task_manager.get_task("process_next_command"):
            self._task_manager.add_task(
                self._process_next_command(),
                "process_next_command",
            )

    async def _process_next_command(self, max_iterations: int | None = None):
        """Process the next command in the queue if no command is currently being sent.

        Args:
            max_iterations (int | None): Maximum iterations for processing commands,
                                        primarily for testing or debugging. If None,
                                        processes until conditions are met.

        """
        iteration_count = 0

        while True:
            if max_iterations and iteration_count >= max_iterations:
                break
            iteration_count += 1

            async with self._state_lock:
                # if self.connection_state.processing_message:
                #     self.log.warning("Waiting for message processing to complete.")
                #     await asyncio.sleep(0.1)
                #     continue

                if self._should_exit_processing():
                    self.log.debug("No more commands in the queue. Exiting loop")
                    break

                command: str = self.connection_state.pop_next_command()
                if not command:
                    continue

                data: bytes = command.encode("utf-8") + CMD_TERMINATOR

            if not await self.send(data):
                break

            self._ok_received.clear()
            try:
                await asyncio.wait_for(
                    self._ok_received.wait(), DEFAULT_COMMAND_TIMEOUT
                )
            except TimeoutError:
                continue

            await asyncio.sleep(1)

    def _should_exit_processing(self) -> bool:
        """Check conditions to exit the processing loop."""
        if self.connection_state.sending_command:
            return True

        if not self.connection_state.has_pending_commands():
            return True

        return False

    async def close(self):
        """Clean up tasks and close the connection."""
        with contextlib.suppress(asyncio.CancelledError):
            await self._task_manager.cancel_all_tasks()

        await self._task_manager.wait_for_all_tasks()
        self.log.info("All tasks cancelled and connection closed.")


class IPHandler(BaseHandler):
    """Handles IP (TCP) communication."""

    async def open_connection(self, host: str, port: int) -> IPHandler:
        """Open an asynchronous ip connection."""
        try:
            self.reader, self.writer = await asyncio.open_connection(host, port)
        except OSError as e:
            self.log.warning("Failed to open IP connection to %s:%d: %s", host, port, e)
            raise

        self.log.info("IP connection established to %s:%d", host, port)

        self._task_manager.add_task(
            self._dispatcher.invoke_event(
                EventType.CONNECTION_STATE,
                state=ConnectionStatus.CONNECTED,
                message=f"Connected to {host}:{port}",
            ),
            "invoke_event",
        )

        self._task_manager.add_task(self.process_stream(), "process_stream")

        return self

    async def send(self, data: bytes) -> None:
        """Send data over the IP connection."""
        if self.writer is None or self.writer.is_closing():
            raise ConnectionError("Writer is closed or unavailable")
        self.writer.write(data)
        await self.writer.drain()
        self.log.debug("Command sent: %s", data)


    async def close(self) -> None:
        """Close."""
        self.log.debug("Closing the Connection")
        await super().close()
        if self.writer:
            self.writer.close()
            try:
                await asyncio.wait_for(self.writer.wait_closed(), timeout=5.0)
            except asyncio.exceptions.TimeoutError:
                self.log.warning("Timeout while waiting for writer to close.")
            finally:
                self.writer = None
                self.reader = None

            self._task_manager.add_task(
                    self._dispatcher.invoke_event(
                        EventType.CONNECTION_STATE,
                        state=ConnectionStatus.DISCONNECTED,
                        message="Disconnected from host",
                    ),
                    "invoke_event",
                )

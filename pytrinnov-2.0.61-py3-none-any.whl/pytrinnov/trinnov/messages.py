"""Class for handling messages from the hardware device."""

from __future__ import annotations

from typing import Any, ClassVar, Literal

from pytrinnov.models.base import (DecoderBase, MachineIdentifier,
                                   NetstatusEth, NetstatusModel,
                                   NetstatusService, NetstatusWlan,
                                   OptimizationFlagsModel, upmixers)

# Message constants
AUDIOSYNC = "AUDIOSYNC"
AUDIOSYNC_STATUS = "AUDIOSYNC_STATUS"
BYPASS = "BYPASS"
CONNECT = "CONNECT"
CURRENT_PRESET = "CURRENT_PRESET"
CURRENT_PROFILE = "CURRENT_PROFILE"
CURRENT_SOURCE_CHANNELS_ORDER = "CURRENT_SOURCE_CHANNELS_ORDER"
CURRENT_SOURCE_FORMAT_NAME = "CURRENT_SOURCE_FORMAT_NAME"
DECODER = "DECODER"
DISCONNECT = "DISCONNECT"
DISPLAY_VOLUME = "DISPLAY_VOLUME"
DIM = "DIM"
ERROR = "ERROR"
FAV_LIGHT = "FAV_LIGHT"
INPUT_CONNECTOR = "INPUT_CONNECTOR"
LABEL = "LABEL"
LABELS_CLEAR = "LABELS_CLEAR"
MON_VOL = "MON_VOL"
MUTE = "MUTE"
NETSTATUS = "NETSTATUS"
OPTIMIZATION = "OPTIMIZATION"
PROFILE = "PROFILE"
PROFILES_CLEAR = "PROFILES_CLEAR"
REMAPPING_MODE = "REMAPPING_MODE"
SOURCES_CHANGED = "SOURCES_CHANGED"
SRATE = "SRATE"
VOLUME = "VOLUME"
UPMIXER = "UPMIXER"
VOLUME_OFFSET = "VOLUME_OFFSET"
WELCOME_MSG = "Welcome on Trinnov Optimizer"

JOINED_MESSAGES = {INPUT_CONNECTOR, CURRENT_SOURCE_FORMAT_NAME}

IGNORED_MESSAGES: set[str] = {
    "BASS_MANAGEMENT",
    "CALIBRATION_DONE",
    "CURRENT_SOURCE_CHANNELS_ORDER_IS_DCI",
    "IDENTS",
    "MON_REMOTE_",
    "OPTSOURCE",
    "PRESET_OUTPUT_VOLUME",
    "RIAA_PHONO",
    "SOURCE",
    "SOURCES_CHANGED",
    "SRPID",
    "START_COMPUTING",
    "START_RUNNING",
    "STOP_COMPUTING",
}


# Registry for automatic response lookup
registry = {}


def register(cls):
    """Register a message response class for factory use."""
    registry[cls.name] = cls
    return cls


def detect_netstatus_type(message: str) -> Literal["ETH", "WLAN", "SERVICE"]:
    """Detect NETSTATUS subtype: returns 'WLAN', 'SERVICE', or 'ETH'."""
    if "WLANMODE" in message:
        return "WLAN"
    if "SERVICE_STATUS" in message:
        return "SERVICE"
    return "ETH"


class MessageParser:
    """Class for parsing messages from the hardware device."""

    def __init__(self, message: str) -> None:
        """Parse string message into its fields."""
        self.message = message
        self.fields: list[str] = self.message.split(" ")
        self.name: str = ""

        if message.startswith(WELCOME_MSG):
            self._handle_welcome_message()
        elif message.startswith(DECODER):
            self._handle_decoder_message()
        elif any(message.startswith(name) for name in JOINED_MESSAGES):
            self._handle_joined_message()
        elif message.startswith(NETSTATUS):
            match detect_netstatus_type(message):
                case "WLAN":
                    self._handle_netstatus_wlan_message()
                case "SERVICE":
                    self._handle_netstatus_service_message()
                case "ETH":
                    self._handle_netstatus_message()
        elif message.startswith(OPTIMIZATION):
            self._handle_optimization_flags_message()
        elif self._handle_upmixer_message():
            self.name = UPMIXER
        else:
            self._parse_name()

    def _handle_welcome_message(self) -> None:
        """Handle parsing when message starts with the welcome message."""
        self.name = WELCOME_MSG

        if len(self.fields) >= 7:
            trimmed_fields = self.fields[5:]
            del trimmed_fields[1]

            trimmed_fields = [f[:-1] for f in trimmed_fields]

            try:
                value = int(trimmed_fields[1])
                trimmed_fields.append(str(value & 0xFFFFF).zfill(6))
                trimmed_fields.append(value >> 20)
            except (ValueError, IndexError):
                return

            self.fields = trimmed_fields

    def _handle_decoder_message(self) -> None:
        """Parse a DECODER message with known key-value pattern."""
        self.name = DECODER

        try:
            self.fields = [
                self.fields[2],  # NONAUDIO value
                self.fields[4],  # PLAYABLE flag
                self.fields[6],  # DECODER value
                self.fields[8],  # UPMIXER value
            ]
        except IndexError:
            self.fields = []

    def _handle_joined_message(self) -> None:
        """Handle parsing of messages where the value is a single joined string."""
        self.name = self.fields[0]
        self.fields = [" ".join(self.fields[1:]).strip()]

    def _handle_netstatus_message(self) -> None:
        """Parse NETSTATUS ETH message fields."""
        self.name = NETSTATUS
        try:
            self.fields = [self.fields[i].strip('"') for i in (3, 5, 7, 9, 11, 13)]
        except IndexError:
            self.fields = []

    def _handle_netstatus_wlan_message(self) -> None:
        """Parse NETSTATUS WLAN message fields."""
        self.name = NETSTATUS
        try:
            self.fields = [
                self.fields[i].strip('"') for i in (3, 5, 7, 9, 11, 13, 15, 17, 19, 21)
            ]
        except IndexError:
            self.fields = []

    def _handle_netstatus_service_message(self) -> None:
        """Parse NETSTATUS SERVICE_STATUS message."""
        self.name = NETSTATUS

        # Safely join and strip quotes from all remaining parts
        value = " ".join(self.message.split(" ")[2:]).strip('"')
        self.fields = [value]

    def _handle_optimization_flags_message(self) -> None:
        """Parse OPTIMIZATION flags into 4 fields."""
        self.name = OPTIMIZATION
        payload = self.message[len(OPTIMIZATION) :].strip()
        parts = [p.strip() for p in payload.split(",")]
        self.fields = [part.split()[-1] for part in parts if part]

    def _handle_upmixer_message(self):
        """Find keys in upmixer dictionary."""
        return any(key in self.message for key in upmixers)

    def _parse_name(self) -> None:
        raw_name = self.fields.pop(0)
        self.name = raw_name.rstrip(":")

    def to_dict(self) -> dict[str, str]:
        """Convert fields into a dict with dynamic keys like field.0, field.1, etc."""
        return {f"field.{i}": value for i, value in enumerate(self.fields)}

    def __str__(self) -> str:
        """Return the message as a string representation of the object."""
        return self.message

    def __repr__(self) -> str:
        """Return a detailed string representation of the object."""
        return (
            f"{type(self).__name__}("
            f"message='{self.message}', "
            f"name='{self.name}', "
            f"fields={self.fields}, "
            ")"
        )


class Response:
    """Base class representing a response from the hardware device."""

    name: str = ""

    def __init__(self, parsed: MessageParser) -> None:
        """Initialize response with parsed fields."""
        self.name = parsed.name
        self._fields = parsed.fields

    @classmethod
    def factory(cls, message: str) -> Response:
        """Create a new response object based on the message type."""
        parsed = MessageParser(message)
        return registry.get(parsed.name, cls)(parsed)

    @property
    def fields(self) -> list:
        """Return message fields."""
        return self._fields


class TypedResponse(Response):
    """Generic response class for different field types."""

    field_type: type[Any] = str  # Default to string

    @property
    def field(self) -> Any:
        """Returns the field converted to the appropriate type."""

        if not self._fields:
            raise IndexError(f"No fields available in {type(self).__name__}")

        raw_value = self._fields[0]  # Store safely before exception handling

        # Special case for boolean fields
        if self.field_type is bool:
            return raw_value == "1"  # "1" -> True, "0" -> False

        try:
            return self.field_type(raw_value)  # Convert to the specified type
        except ValueError as e:
            raise ValueError(
                f"Invalid {self.field_type.__name__} value: {raw_value!r} in {type(self).__name__}"
            ) from e


@register
class Audiosync(TypedResponse):
    """Audiosync Message."""

    name = AUDIOSYNC


@register
class AudiosyncStatus(TypedResponse):
    """Audiosync Status Message."""

    name = AUDIOSYNC_STATUS
    field_type = bool


@register
class Bypass(TypedResponse):
    """Bypass Status Message."""

    name = BYPASS
    field_type = bool


@register
class Connect(Response):
    """Class for Connect message."""

    name = CONNECT


@register
class CurrentPreset(TypedResponse):
    """Class for Current Preset message."""

    name = CURRENT_PRESET


@register
class CurrentProfile(TypedResponse):
    """Class for Current Profile message."""

    name = CURRENT_PROFILE
    field_type = int


@register
class CurrentSourceChannelsOrder(TypedResponse):
    """Class for Current Source Channels Order message."""

    name = CURRENT_SOURCE_CHANNELS_ORDER


@register
class CurrentSourceFormatName(TypedResponse):
    """Class for Current Source Format Name message."""

    name = CURRENT_SOURCE_FORMAT_NAME


@register
class Disconnect(Response):
    """Class for Disconnect message."""

    name = DISCONNECT


@register
class Decoder(DecoderBase):
    """Class for Decoder message."""

    name: ClassVar[str] = DECODER

    def __init__(self, parsed: MessageParser) -> None:
        """Initialize from parsed data."""
        super().__init__(**parsed.to_dict())


@register
class Dim(TypedResponse):
    """Dim Status Message."""

    name = DIM
    field_type = bool


@register
class DisplayVolume(TypedResponse):
    """Display Volume Level Message."""

    name = DISPLAY_VOLUME
    field_type = float


@register
class Error(TypedResponse):
    """Class for Error message."""

    name = ERROR


@register
class FavLight(TypedResponse):
    """Class for fav_light message."""

    name = FAV_LIGHT
    field_type = bool


@register
class InputConnector(TypedResponse):
    """Class for Input_Connector message."""

    name = INPUT_CONNECTOR


@register
class Label(TypedResponse):
    """Class for Label message."""

    name = LABEL


@register
class LabelsClear(Response):
    """Class for Labels Clear message."""

    name = LABELS_CLEAR


@register
class MonVol(TypedResponse):
    """Mon Volume Message."""

    name = MON_VOL
    field_type = float


@register
class Mute(TypedResponse):
    """Mute Status Message."""

    name = MUTE
    field_type = bool


@register
class NetStatus(Response):
    """Unified handler for NETSTATUS messages (ETH or WLAN)."""

    name: ClassVar[str] = NETSTATUS
    data: NetstatusModel

    def __init__(self, parsed: MessageParser) -> None:
        """Initialize and choose the correct model."""
        super().__init__(parsed)

        data = parsed.to_dict()
        message_type = detect_netstatus_type(parsed.message)

        match message_type:
            case "WLAN":
                data["type"] = "WLAN"
                self.data = NetstatusWlan(**data)
            case "SERVICE":
                data["type"] = "SERVICE"
                self.data = NetstatusService(**data)
            case "ETH":
                data["type"] = "ETH"
                self.data = NetstatusEth(**data)

    def __getattr__(self, item):
        """Forward attribute access to the underlying parsed model."""
        return getattr(self.data, item)

    @property
    def is_eth(self) -> bool:
        """True if the message is an Ethernet (ETH) status."""
        return isinstance(self.data, NetstatusEth)

    @property
    def is_wlan(self) -> bool:
        """True if the message is a Wireless (WLAN) status."""
        return isinstance(self.data, NetstatusWlan)


@register
class OptimizationFlags(OptimizationFlagsModel):
    """Message class for parsed OPTIMIZATION flags."""

    name: ClassVar[str] = OPTIMIZATION

    def __init__(self, parsed: MessageParser) -> None:
        """Initialize from parsed OPTIMIZATION message."""
        super().__init__(**parsed.to_dict())


@register
class Profile(TypedResponse):
    """Class for Profile message."""

    name = PROFILE


@register
class ProfilesClear(Response):
    """Class for Profiles Clear message."""

    name = PROFILES_CLEAR


@register
class RemappingMode(TypedResponse):
    """Class for Remapping Mode message."""

    name = REMAPPING_MODE


@register
class SourcesChanged(Response):
    """Class for Sources Changed message."""

    name = SOURCES_CHANGED


@register
class Srate(TypedResponse):
    """Sample Rate Message."""

    name = SRATE
    field_type = float


@register
class Volume(TypedResponse):
    """Volume Level Message."""

    name = VOLUME
    field_type = float


@register
class VolumeOffset(TypedResponse):
    """Volume Offset Message."""

    name = VOLUME_OFFSET
    field_type = float


@register
class Upmixer(TypedResponse):
    """Class for Upmixer message."""

    name = UPMIXER


@register
class Welcome(MachineIdentifier):
    """Welcome Message."""

    name: ClassVar[str] = WELCOME_MSG

    def __init__(self, parsed: MessageParser) -> None:
        """Initialize from parsed data."""
        super().__init__(**parsed.to_dict())

"""Module: DeviceManager."""

import asyncio
import contextlib
import re
from collections.abc import Callable, Coroutine
from functools import partial
from typing import Any

from pytrinnov.models.base import AudioSettings, DecoderBase, MachineIdentifier
from pytrinnov.models.constants import ConnectionStatus, EventType
from pytrinnov.utils.logging_utils import LoggingMixin, custom_log_pprint
from pytrinnov.utils.settings_updater import (apply_audio_message,
                                              apply_profile_message)

from .commands import (CMD_GET_CURRENT_PROFILE, CMD_GET_CURRENT_STATE, CMD_ID,
                       CMD_UPMIXER)
from .config import DEFAULT_PROTOCOL_PORT
from .connection import ConnectionConfig, ConnectionManager, IPHandler
from .dispatcher import Dispatcher
from .executor import CommandExecutor
from .messages import (IGNORED_MESSAGES, Audiosync, AudiosyncStatus, Bypass,
                       CurrentPreset, CurrentProfile,
                       CurrentSourceChannelsOrder, CurrentSourceFormatName,
                       Decoder, Dim, DisplayVolume, Error, FavLight,
                       InputConnector, Label, LabelsClear, MonVol, Mute,
                       NetStatus, OptimizationFlags, Profile, ProfilesClear,
                       RemappingMode, SourcesChanged, Srate, TypedResponse,
                       Upmixer, Volume, VolumeOffset, Welcome)


class DeviceContext: # pylint: disable=too-few-public-methods
    """Encapsulate device state and connection management."""

    def __init__(self, reconnect: bool) -> None:
        """Initialize the DeviceContext instance."""
        self.connection = ConnectionManager(
            config=ConnectionConfig(reconnect_enabled=reconnect)
        )


class DeviceManager(LoggingMixin):
    """Manage the device's connection, state, and command execution."""

    # Mapping of class names to actual class references
    _audio_settings_classes = {
        "Audiosync": Audiosync,
        "AudiosyncStatus": AudiosyncStatus,
        "Bypass": Bypass,
        "CurrentPreset": CurrentPreset,
        "CurrentProfile": CurrentProfile,
        "CurrentSourceChannelsOrder": CurrentSourceChannelsOrder,
        "CurrentSourceFormatName": CurrentSourceFormatName,
        "Dim": Dim,
        "DisplayVolume": DisplayVolume,
        "FavLight": FavLight,
        "InputConnector": InputConnector,
        "MonVol": MonVol,
        "Mute": Mute,
        "RemappingMode": RemappingMode,
        "Srate": Srate,
        "Upmixer": Upmixer,
        "Volume": Volume,
        "VolumeOffset": VolumeOffset,
    }

    def __init__(self, reconnect: bool = True) -> None:
        """Initialize the Device instance.

        Args:
            connection_type (str): Type of connection ("serial" or "ip").
            reconnect (bool): Whether to enable automatic reconnection on disconnection.

        """

        super().__init__()

        self.context = DeviceContext(reconnect)
        # self.context.system_state.set_update_callback(self._device_info_callback)

        self.context.connection.dispatcher.register_listener(
            EventType.CONNECTION_STATE, self._async_event_handler
        )
        self.context.connection.dispatcher.register_listener(
            EventType.DATA_RECEIVED, self._async_event_handler
        )

        self._audio_settings: AudioSettings = AudioSettings()

        """Initialize handlers dynamically."""
        self._message_handlers = {
            cls_obj: self._make_handler(self._convert_to_snake_case(cls_name))
            for cls_name, cls_obj in self._audio_settings_classes.items()
        }
        self._message_handlers[Decoder] = self._handle_decoder
        self._message_handlers[Error] = self._handle_error
        self._message_handlers[Label] = self._handle_label
        self._message_handlers[LabelsClear] = self._handle_labels_clear
        self._message_handlers[NetStatus] = self._handle_netstatus
        self._message_handlers[OptimizationFlags] = self._handle_optimization_flags
        self._message_handlers[Profile] = self._handle_profile
        self._message_handlers[ProfilesClear] = self._handle_profiles_clear
        self._message_handlers[SourcesChanged] = self._handle_sources_changed
        self._message_handlers[Welcome] = self._handle_welcome

    @property
    def dispatcher(self) -> Dispatcher:
        """Dispatcher."""
        return self.context.connection.dispatcher

    @property
    def executor(self) -> CommandExecutor:
        """Expose the CommandExecutor instance."""
        if self.context.connection.executor is None:
            raise RuntimeError(
                "CommandExecutor is not initialized. Ensure `open()` is called first."
            )
        return self.context.connection.executor

    @property
    def audio_settings(self) -> AudioSettings:
        """Expose the Audio Settings."""
        return self._audio_settings

    async def open(self, **kwargs) -> None:
        """Open a connection based on the connection type.

        For serial:
            kwargs: port (str), baudrate (int)
        For IP:
            kwargs: host (str), port (int)
        """
        try:
            self.context.connection.config.connection_params = kwargs.copy()

            self.context.connection.handler = await self._init_ip_handler(**kwargs)
            self.context.connection.executor = CommandExecutor(
                self.context.connection.handler, self
            )
            self.log.info("Connection opened successfully")

        except ValueError as e:
            self.log.error("Failed to open connection: %s", e)
            raise

    async def close(self) -> None:
        """Close the connection and cancel all managed tasks safely."""

        if self.context.connection.closing:
            self.log.info("Close operation already in progress.")
            return

        self.context.connection.closing = True
        self.log.info("Closing device connection...")

        if self.context.connection.handler:
            try:
                await self.context.connection.handler.close()
            except (ConnectionError, asyncio.exceptions.TimeoutError, OSError) as e:
                self.log_error("Error while closing connection handler: %s", e)
            finally:
                self.context.connection.handler = None

        with contextlib.suppress(asyncio.CancelledError):
            await self.context.connection.task_manager.cancel_all_tasks()

        self.context.connection.config.status = ConnectionStatus.DISCONNECTED
        # self.context.system_state.reset_state()

    async def send_command(self, command: str | list[str]) -> None:
        """Send a command to the device via the CommandExecutor."""
        return await self.context.connection.executor.send_command(command)

    async def _init_ip_handler(self, host: str, port: int | None = None) -> IPHandler:
        """Initialize an IP connection with a default port if none is provided."""

        if not host:
            raise ValueError("Host must be provided for IP connection")

        if port is None:
            port = DEFAULT_PROTOCOL_PORT

        self.log.info("Opening IP connection to %s:%d", host, port)

        ip_handler = IPHandler(self.context.connection.dispatcher)
        await ip_handler.open_connection(host, port)

        return ip_handler

    async def _async_event_handler(
        self, event_type: EventType, event_data: dict
    ) -> None:
        """Handle events from the connection handler using TaskGroup for safe async execution."""

        if not isinstance(event_type, EventType):
            self.log.error("Invalid event type received: %s", event_type)
            return

        event_messages = {
            EventType.CONNECTION_STATE: "Received connection state event: %s",
            EventType.DATA_RECEIVED: "Data received: %s",
        }

        self.log.debug(
            event_messages.get(event_type, "Unknown event: %s"),
            event_data.get("message", "No message provided"),
        )

        match event_type:
            case EventType.CONNECTION_STATE:
                state = event_data.get("state")

                if state is None:
                    self.log.error("Missing 'state' key in event_data: %s", event_data)
                    return

                try:
                    self.context.connection.config.status = ConnectionStatus(state)
                    self.log.info(
                        "Updated connection status: %s",
                        self.context.connection.config.status.name,
                    )
                except ValueError:
                    self.log.error(
                        "Invalid connection state received: %s. Defaulting to DISCONNECTED.",
                        state,
                    )
                    self.context.connection.config.status = (
                        ConnectionStatus.DISCONNECTED
                    )

                if self.context.connection.config.status == ConnectionStatus.CONNECTED:
                    self.log.info("Device connected.")

                    await self.context.connection.task_manager.cancel_task(
                        "reconnect_loop"
                    )

                elif (
                    self.context.connection.config.status
                    == ConnectionStatus.DISCONNECTED
                ):
                    self.context.connection.handler = None

                    self.log.warning("Connection lost. is_connected set to False.")


            case EventType.DATA_RECEIVED:
                response = event_data.get("response")

                if response is None:
                    self.log.error(
                        "Missing 'response' key in event_data: %s", event_data
                    )
                    return

                self.context.connection.task_manager.add_task(
                    lambda: self._handle_data_received(response),
                    name="handle_data_received"
                )

    async def _handle_data_received(self, response: Any) -> None:
        """Handle responses received from the hardware."""

        response_name = getattr(response, "name", type(response).__name__)
        self.log_debug("Handling received response: %s", response_name)

        try:
            handler = self._get_message_handler(response, response_name)

            if not handler:
                return

            if not isinstance(handler, (Callable, Coroutine)):
                self.log_error("Invalid handler for %s: %s", response_name, handler)
                return

            if asyncio.iscoroutinefunction(handler):
                await handler(response)
            else:
                handler(response)

        except Exception as e:
            self.log_critical("Error while handling %s: %s", response_name, e)
            raise

    def _make_handler(self, state_attr: str) -> Callable[[Any], Any]:
        """Create partial functions for audio settings."""
        return partial(self._handle_audio_settings, state_attr=state_attr)

    def _convert_to_snake_case(self, name: str) -> str:
        """Convert CamelCase class names to snake_case for attribute names."""
        return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()

    def _get_message_handler(
        self, response: Any, response_name: str
    ) -> Callable[[Any], Any] | None:
        """Retrieve the appropriate handler for a given response object."""

        handler = self._message_handlers.get(type(response))

        if handler is None:
            if any(response_name.startswith(prefix) for prefix in IGNORED_MESSAGES):
                self.log.debug("Ignored known but unhandled message: %s", response_name)
            else:
                self.log.warning("Unhandled and unknown message: %s", response_name)

        return handler

    async def _handle_audio_settings(
        self, response: TypedResponse, state_attr: str
    ) -> None:
        """Handle updates for Audio Settings."""

        if state_attr in self._audio_settings.model_fields:
            self._audio_settings = self._audio_settings.update(
                **{state_attr: response.field}
            )
        else:
            raise ValueError(f"Invalid state attribute: {state_attr}")

        await self.context.connection.dispatcher.invoke_event(
            state_attr,
            value=response.field,
        )

        custom_log_pprint(
            self._audio_settings.model_dump(exclude_unset=False),
            self.log.debug,
        )

    async def _handle_decoder(self, response: DecoderBase) -> None:
        """Handle updates for Decoder Message."""

        if not isinstance(response, DecoderBase):
            self.log.error(
                "Invalid response type for Decoder Message: %s",
                type(response).__name__,
            )
            return

        custom_log_pprint(
            response.model_dump(),
            self.log.debug,
        )

    async def _handle_error(self, response: Error) -> None:
        """Handle updates for Error Message."""

        if not isinstance(response, Error):
            self.log.error(
                "Invalid response type for Error Message: %s",
                type(response).__name__,
            )
            return
        self.log.error("Received Error Message from the Device: %s", response.fields[0])

    async def _handle_netstatus(self, response: NetStatus) -> None:
        """Handle updates for Netstatus Message."""

        if not isinstance(response, NetStatus):
            self.log.error(
                "Invalid response type for Netstatus Message: %s",
                type(response).__name__,
            )
            return

        custom_log_pprint(
            response.model_dump(),
            self.log.debug,
        )

    async def _handle_welcome(self, response: MachineIdentifier) -> None:
        """Handle updates for Welcome Message."""

        if not isinstance(response, MachineIdentifier):
            self.log.error(
                "Invalid response type for Welcome Message: %s",
                type(response).__name__,
            )
            return

        custom_log_pprint(
            response.model_dump(),
            self.log.info,
        )
        await self.send_command(f"{CMD_ID}")
        await self.send_command(f"{CMD_GET_CURRENT_STATE}")

    async def _handle_label(self, response: Label) -> None:
        self._audio_settings = apply_audio_message(self._audio_settings, response)
        custom_log_pprint(
            self._audio_settings.model_dump(exclude_unset=False),
            self.log.debug,
        )

    async def _handle_labels_clear(self, response: LabelsClear) -> None:
        self._audio_settings = apply_audio_message(self._audio_settings, response)
        custom_log_pprint(
            {"labels (cleared)": self._audio_settings.labels}, self.log.debug
        )

    async def _handle_optimization_flags(self, response: OptimizationFlags) -> None:
        """Handle OPTIMIZATION flags message."""
        self._audio_settings = self._audio_settings.update(optimization=response)
        custom_log_pprint({"optimization_flags": response.model_dump()}, self.log.info)

    async def _handle_profile(self, response: Profile) -> None:
        """Handle a PROFILE message and update AudioSettings.profiles."""
        self._audio_settings = apply_profile_message(self._audio_settings, response)

        if len(self._audio_settings.profiles) == 31:
            attr = "input_labels"
            async def invoke_labels_updated(attr=attr, value=self._audio_settings.profiles):
                await self.context.connection.dispatcher.invoke_event(
                    attr,
                    value=value,
                )

            self.context.connection.task_manager.add_task(
                invoke_labels_updated(), name=f"invoke_event_{attr}"
            )

            custom_log_pprint(
                self._audio_settings.model_dump(exclude_unset=False),
                self.log.debug,
            )

    async def _handle_profiles_clear(self, response: ProfilesClear) -> None:
        """Handle a PROFILES_CLEAR message to reset profiles."""
        self._audio_settings = apply_profile_message(self._audio_settings, response)
        custom_log_pprint(
            {"profiles (cleared)": self._audio_settings.profiles}, self.log.debug
        )

    async def _handle_sources_changed(self, _: SourcesChanged) -> None:
        """Handle function for Sources Changed messages."""
        await self.send_command(f"{CMD_GET_CURRENT_PROFILE}")
        await self.send_command(f"{CMD_UPMIXER}")

    async def show_audio_settings(self) -> None:
        """Show Audio Settings."""
        custom_log_pprint(
            self._audio_settings.model_dump(exclude_unset=False),
            self.log.info,
        )

"""Module: CommandExecutor.

Handles execution of device commands by grouping them into specialized command handlers.
This improves **organization**, **maintainability**, and **structured control** over the device.
"""
# pylint: disable=too-few-public-methods

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from wakeonlan import send_magic_packet

from pytrinnov.utils.logging_utils import LoggingMixin

from .commands import (CMD_BYPASS, CMD_DIM, CMD_DVOLUME, CMD_FAV_LIGHT,
                       CMD_MUTE, CMD_POWER_OFF, CMD_PROFILE, CMD_UPMIXER,
                       CMD_VOLUME)
from .connection import BaseHandler

if TYPE_CHECKING:  # pragma: no cover
    from .device import DeviceManager


class CommandSender(LoggingMixin):
    """Handles sending raw commands to the device."""

    def __init__(self, connection_handler: BaseHandler) -> None:
        """Initialize with a connection handler."""
        super().__init__()
        self._handler = connection_handler

    async def send_command(self, command: str | list[str]) -> None:
        """Send a command or list of commands over the connection."""
        try:
            if isinstance(command, str):
                commands = [command.strip()] if command.strip() else []
            elif isinstance(command, list):
                commands = [
                    cmd.strip()
                    for cmd in command
                    if isinstance(cmd, str) and cmd.strip()
                ]
            else:
                self.log.error("Invalid command type: %s", type(command).__name__)
                return

            if not commands:
                self.log.warning("No valid commands to send after filtering.")
                return

            await self._handler.queue_command(commands)
        except AttributeError as e:
            self.log.error("Attribute error in send_command(): %s", e)
        except TypeError as e:
            self.log.error("Type error in send_command(): %s", e)
        except asyncio.exceptions.TimeoutError as e:
            self.log.error("Timeout while sending command: %s", e)
        except ConnectionError as e:
            self.log.error("Connection error while sending command: %s", e)
        except RuntimeError as e:
            self.log.error("Runtime error while sending command: %s", e)


class PowerControl:
    """Handles power state transitions."""

    def __init__(self, sender: CommandSender) -> None:
        """Initialize with a command sender and device manager."""
        self.sender = sender

    async def power_off(self) -> None:
        """Turn the device off."""
        await self.sender.send_command(CMD_POWER_OFF)

    @staticmethod
    async def power_on(mac_address: str) -> None:
        """Turn the device on."""
        send_magic_packet(mac_address)


class PowerControlMixin:
    """Mixin for power state transitions."""

    power: PowerControl

    async def power_off(self) -> None:
        """Turn the device off."""
        await self.power.power_off()


class RemoteControl(LoggingMixin):
    """Handles remote commands for menus and settings."""

    def __init__(self, sender: CommandSender, device_manager: DeviceManager) -> None:
        """Initialize with a command sender."""
        super().__init__()
        self.sender = sender
        self.dm = device_manager

    async def bypass(self, action: int) -> None:
        """
        Send BYPASS command to the device.

        This command allows changing the bypass state:
            - If action is 0, bypass is disabled.
            - If action is 1, bypass is enabled.
            - If action is 2, bypass state is inverted (toggle).

        Args:
            action (int): Bypass action (0 = off, 1 = on, 2 = toggle).
        """
        await self.sender.send_command(f"{CMD_BYPASS} {action}")

    async def dim(self, action: int) -> None:
        """
        Send DIM command to the device.

        This command allows changing the dim state:
            - If action is 0, dim is disabled.
            - If action is 1, dim is enabled.
            - If action is 2, dim state is inverted (toggle).

        Args:
            action (int): Dim action (0 = off, 1 = on, 2 = toggle).
        """
        await self.sender.send_command(f"{CMD_DIM} {action}")

    async def fav_light(self, mode: int) -> None:
        """
        Send FAV LIGHT command to the device.

        This command gets or sets the front panel display mode based on the <mode> value:
            - No argument: returns current front panel display status.
            - 1: turns off the front panel display.
            - 0: turns on the front panel display.
            - 2: toggles the display status (same as Light button on remote).

        Args:
            mode (int): Display mode (0 = on, 1 = off, 2 = toggle).
        """
        await self.sender.send_command(f"{CMD_FAV_LIGHT} {mode}")

    async def mute(self, action: int) -> None:
        """
        Send Mute command to the device.

        This command allows changing the mute state:
            - If action is 0, mute is disabled (sound is enabled).
            - If action is 1, mute is enabled (sound is disabled).
            - If action is 2, mute state is inverted.

        Args:
            action (int): Mute action (0 = unmute, 1 = mute, 2 = toggle).
        """
        await self.sender.send_command(f"{CMD_MUTE} {action}")

    async def select_sound_mode(self, upmixer: str) -> None:
        """Send Select Sound Mode command."""
        await self.sender.send_command(f"{CMD_UPMIXER} {upmixer}")

    async def upmixer(self, mode: str) -> None:
        """
        Send UPMIXER command to the device.

        This command allows getting or setting the upmixer mode of the Altitude device,
        depending on the provided <mode> argument:

            - No argument: returns the current upmixer mode.
            - '+' or '1': switches to the next upmixer mode.
            - '-' or '0': switches to the previous upmixer mode.
            - 'auro3d', 'dts', 'dolby', 'auto', 'native', 'legacy', or 'upmix on native':
            switches to the corresponding upmixer mode.

        Args:
            mode (str): The upmixer mode command or name to apply.
        """
        await self.sender.send_command(f"{CMD_UPMIXER} {mode}")

    async def select_source(self, source: int) -> None:
        """Send Select Source command."""
        await self.sender.send_command(f"{CMD_PROFILE} {source}")

    async def volume(self, volume: str) -> None:
        """
        Set the main volume to a specified level in dB.

        Sends the command `volume <volume>` to adjust the master volume level,
        where `<volume>` is a string representing the desired level in decibels (e.g., "-30.0").
        This sets the main volume as shown in the GUI of the Altitude processor.

        Args:
            volume (str): The target volume level in dB, formatted as a string.
        
        Example:
            await self.volume("-25.0")
        """
        await self.sender.send_command(f"{CMD_VOLUME} {volume}")

    async def volume_down(self) -> None:
        """Send Volume down command."""
        await self.sender.send_command(f"{CMD_DVOLUME} -1")

    async def volume_up(self) -> None:
        """Send Volume Up command."""
        await self.sender.send_command(f"{CMD_DVOLUME} 1")


class RemoteControlMixin:
    """Mixin for handling remote commands for menus and settings."""

    remote: RemoteControl

    async def bypass(self, action: int = 2) -> None:
        """
        Send Bypass command to the device.

        This command allows changing the bypass state:
            - If action is 0, bypass is disabled.
            - If action is 1, bypass is enabled.
            - If action is 2, bypass state is inverted (toggle).

        Args:
            action (int, optional): Bypass action (0 = off, 1 = on, 2 = toggle). Defaults to 2.
        """
        await self.remote.bypass(action)

    async def dim(self, action: int = 2) -> None:
        """
        Send Dim command to the device.

        This command allows changing the dim state:
            - If action is 0, dim is disabled.
            - If action is 1, dim is enabled.
            - If action is 2, dim state is inverted (toggle).

        Args:
            action (int, optional): Dim action (0 = off, 1 = on, 2 = toggle). Defaults to 2.
        """
        await self.remote.dim(action)

    async def fav_light(self, mode: int = 2) -> None:
        """
        Change front panel display mode using FAV LIGHT command.

        This command allows getting or setting the front panel display mode:
            - 0 = on
            - 1 = off
            - 2 = toggle (default)

        Args:
            mode (int, optional): Display mode control. Defaults to 2.
        """
        await self.remote.fav_light(mode)

    async def mute(self, action: int = 2) -> None:
        """
        Send Mute command to the device.

        This command allows changing the mute state:
            - If action is 0, mute is disabled (sound is enabled).
            - If action is 1, mute is enabled (sound is disabled).
            - If action is 2, mute state is inverted (toggle).

        Args:
            action (int, optional): Mute action (0 = unmute, 1 = mute, 2 = toggle). Defaults to 2.
        """
        await self.remote.mute(action)

    async def select_sound_mode(self, upmixer: str) -> None:
        """Send Select Sound Mode command."""
        await self.remote.select_sound_mode(upmixer)

    async def upmixer(self, mode: str) -> None:
        """
        Send UPMIXER command to the device.

        This command allows getting or setting the upmixer mode of the Altitude device,
        based on the provided <mode> argument:

            - If no argument is provided, the current upmixer mode is returned.
            - If mode is '+' or '1', switches to the next upmixer mode.
            - If mode is '-' or '0', switches to the previous upmixer mode.
            - If mode is one of 'auro3d', 'dts', 'dolby', 'auto', 'native', 'legacy',
            or 'upmix on native', switches to the corresponding upmixer mode.

        Args:
            mode (str): The upmixer mode command or name to apply.
        """
        await self.remote.upmixer(mode)

    async def select_source(self, source: int) -> None:
        """Send Select Source command."""
        await self.remote.select_source(source)

    async def volume(self, volume: str) -> None:
        """
        Send a command to set the main volume to a specific dB value.

        This command changes the master volume level to the specified value in decibels (dB),
        as displayed in the Altitude GUI.

        Args:
            volume (str): The desired volume level in dB (e.g., "-30.0", "0.0").

        Example:
            await self.volume("-20.5")
        """
        await self.remote.volume(volume)

    async def volume_down(self) -> None:
        """Send Volume down command."""
        await self.remote.volume_down()

    async def volume_up(self) -> None:
        """Send Volume up command."""
        await self.remote.volume_up()


class CommandExecutor(
    LoggingMixin,
    RemoteControlMixin,
    PowerControlMixin,
):
    """The main command executor that combines all functionality."""

    def __init__(
        self, connection_handler: BaseHandler, device_manager: DeviceManager
    ) -> None:
        """Initialize and set up all command groups.

        Args:
            connection_handler (BaseHandler): The device connection handler.
            device_manager (DeviceManager): The device manager instance.

        """
        super().__init__()
        self.dm = device_manager
        self.sender = CommandSender(connection_handler)

        self._controls = {
            "power": PowerControl(self.sender),
            "remote": RemoteControl(self.sender, self.dm),
        }

    def __getattr__(self, name):
        """Efficiently resolve attributes dynamically with caching."""

        if name in self._controls:
            setattr(self, name, self._controls[name])
            return self._controls[name]

        for control in self._controls.values():
            if hasattr(control, name):
                setattr(self, name, getattr(control, name))
                return getattr(self, name)

        raise AttributeError(
            f"'{self.__class__.__name__}' object has no attribute '{name}'"
        )

    async def send_command(self, command: str) -> None:
        """Send a command using the main executor."""
        await self.sender.send_command(command)

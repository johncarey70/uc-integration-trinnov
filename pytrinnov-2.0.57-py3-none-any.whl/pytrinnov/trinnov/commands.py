"""Command definitions for device communication."""

# Command identifiers
CMD_ACK = "OK"
CMD_TERMINATOR = b"\n"


CMD_ID = "id home_assistant"
CMD_GET_CURRENT_PROFILE = "get_current_profile"
CMD_GET_CURRENT_STATE = "get_current_state"

CMD_BYPASS = "bypass"
CMD_DIM = "dim"
CMD_DVOLUME = "dvolume"
CMD_FAV_LIGHT = "fav_light"
CMD_GET_CURRENT_PROFILE = "get_current_profile"
CMD_GET_CURRENT_STATE = "get_current_state"
CMD_MUTE = "mute"
CMD_POWER_OFF = "power_off_SECURED_FHZMCH48FE"
CMD_PROFILE = "profile"
CMD_UPMIXER = "upmixer"
CMD_VOLUME = "volume"

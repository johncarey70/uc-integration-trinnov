"""WebSocket Module."""

import asyncio
import json
import logging
import re
import struct

import websockets

from pytrinnov.models.base import (ConfigStatus, EthernetStatus,
                                   GenericResponseModel, SystemUpdateStatus)
from pytrinnov.models.constants import WS_CONFIG, WS_ETHERNET, WS_UPDATES

_LOGGER = logging.getLogger(__name__)

class DeviceError(Exception):
    """Custom exception for WebSocket errors."""


class WebSocketClient:
    """WebSocket client for communicating with a server."""

    def __init__(
        self, host_ip: str, timeout: int = 10, retries: int = 3, port: int = 80
    ) -> None:
        """Initialize the WebSocket client."""
        self.host_ip = host_ip
        self.timeout = timeout
        self.retries = retries
        self.websocket = None
        self.port = port

    async def __aenter__(self):
        """Establish WebSocket connection with a graceful timeout."""
        try:
            _LOGGER.info("Connecting to WebSocket at %s:%d", self.host_ip, self.port)
            self.websocket = await asyncio.wait_for(
                websockets.connect(f"ws://{self.host_ip}:{self.port}/ws"),
                timeout=self.timeout,
            )
            return self  # noqa: TRY300
        except asyncio.exceptions.TimeoutError as exc:
            _LOGGER.error(
                "WebSocket connection to %s timed out after %d seconds",
                self.host_ip,
                self.timeout,
            )
            raise DeviceError(f"Connection to {self.host_ip} timed out") from exc
        except asyncio.CancelledError as exc:
            _LOGGER.warning(
                "WebSocket connection attempt to %s was cancelled", self.host_ip
            )
            raise DeviceError(f"Connection to {self.host_ip} was cancelled") from exc
        except OSError as exc:
            _LOGGER.error(
                "Network error: Unable to reach %s. Ensure the device is powered on, "
                "the IP address is correct, and the correct WebSocket port is used. "
                "Error: %s",
                self.host_ip,
                exc,
            )
            raise DeviceError(
                f"Network error: Unable to reach {self.host_ip}. "
                "Make sure the device is ON and using the correct port."
            ) from exc
        except Exception as exc:
            _LOGGER.exception("Unexpected error while connecting to WebSocket")
            raise DeviceError(
                f"Unexpected WebSocket connection error: {exc!s}"
            ) from exc

    async def __aexit__(self, exc_type, exc, tb):
        """Ensure WebSocket connection is closed gracefully."""
        if self.websocket:
            _LOGGER.info("Closing WebSocket connection to %s", self.host_ip)
            await self.websocket.close()

    async def send_and_receive(self, messages: list):
        """Send messages to the WebSocket server and process responses."""
        responses = {}

        for attempt in range(self.retries):
            try:
                for path, message_type, json_data in messages:
                    buffer = self.create_buffer(path, message_type, json_data)
                    await self.websocket.send(buffer)

                    if json_data is None:
                        result = await asyncio.wait_for(
                            self.websocket.recv(), timeout=self.timeout
                        )

                        decoded_message = self.decode_message(result)
                        model = self.parse_response(path, decoded_message)
                        responses[path] = model
                return responses  # noqa: TRY300

            except asyncio.exceptions.TimeoutError:
                _LOGGER.warning(
                    "Timeout occurred, retrying %d/%d", attempt + 1, self.retries
                )
                await asyncio.sleep(2**attempt)

            except websockets.ConnectionClosedError as connection_error:
                raise DeviceError(
                    "Connection closed unexpectedly"
                ) from connection_error
            except Exception as general_error:
                _LOGGER.exception("Unexpected error on path %s", path)
                raise DeviceError(
                    f"Error processing response from {path}"
                ) from general_error

        raise DeviceError("Failed to communicate with the server after all retries")

    @staticmethod
    def create_buffer(path: str, message_type: int, json_data: str = ""):
        """Create a binary buffer containing metadata and path information."""
        path_buf = path.encode("utf-8")
        buff_needed_size = len(path_buf) + 1 + 4

        data_buf = None
        if json_data:
            data_buf = json.dumps(json_data).encode("utf-8")
            buff_needed_size += len(data_buf)

        buffer = bytearray(buff_needed_size + 4)
        struct.pack_into(">I", buffer, 0, buff_needed_size)
        struct.pack_into(">B", buffer, 4, message_type)
        struct.pack_into(">I", buffer, 5, len(path_buf))

        buffer[9 : 9 + len(path_buf)] = path_buf
        if data_buf:
            start = 9 + len(path_buf)
            buffer[start : start + len(data_buf)] = data_buf

        return buffer

    @staticmethod
    def decode_message(message: bytes):
        """Decode a WebSocket message and extract JSON data."""
        try:
            decoded_message = message.decode(
                "latin-1", errors="ignore"
            )  # Prevents decoding errors

            match = re.search(r"\{.*\}", decoded_message)
            if match:
                json_string = match.group(0)
                return json.loads(json_string)  # Always returns a dictionary

            _LOGGER.warning(
                "No valid JSON found in WebSocket message. Returning empty dictionary"
            )
            return {}  # noqa: TRY300

        except (UnicodeDecodeError, json.JSONDecodeError) as err:
            raise DeviceError(f"Error decoding message: {err}") from err

    @staticmethod
    def parse_response(path: str, response_data: dict):
        """Parse response JSON into Pydantic models."""

        if path == WS_ETHERNET:
            return EthernetStatus.model_validate(response_data)
        if path == WS_CONFIG:
            return ConfigStatus.model_validate(response_data)
        if path == WS_UPDATES:
            return SystemUpdateStatus.model_validate(response_data)

        _LOGGER.warning(
            "Unknown path received: %s. Returning raw dictionary as a model", path
        )
        return GenericResponseModel(raw_data=response_data)

async def main():
    host_ip = "192.168.15.30"
    messages = [
        (WS_ETHERNET, 1, None)
    ]

    try:
        async with WebSocketClient(host_ip, port=80) as client:
            responses = await client.send_and_receive(messages)
            for path, response_model in responses.items():
                print(f"Path: {path}")
                print("Response:", response_model.model_dump())
    except DeviceError as e:
        print(f"Device communication failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())

"""Helpers for applying incoming Trinnov messages to update client-side settings.

This module provides functions to incrementally update fields in the AudioSettings model
based on parsed protocol messages like LABEL, PROFILE, LABELS_CLEAR, and PROFILES_CLEAR.

It is designed to avoid circular imports between the core models and message parsing logic.
"""

from pytrinnov.models.base import AudioSettings
from pytrinnov.trinnov.messages import Label, LabelsClear, Profile, ProfilesClear


def _apply_indexed_update(
    settings: AudioSettings, message, *, clear_cls, update_cls, field_name: str
) -> AudioSettings:
    """Handle indexed key-value messages like LABEL and PROFILE."""

    if isinstance(message, clear_cls):
        return settings.update(**{field_name: {}})

    if isinstance(message, update_cls):
        fields = message.fields
        if len(fields) >= 2:
            key_part, *value_parts = fields
            if key_part.endswith(":"):
                try:
                    index = int(key_part.rstrip(":"))
                    value = " ".join(value_parts).strip()
                    current = getattr(settings, field_name)
                    return settings.update(**{field_name: {**current, index: value}})
                except ValueError:
                    pass

    return settings


def apply_audio_message(settings: AudioSettings, message) -> AudioSettings:
    """Apply LABEL or LABELS_CLEAR messages to AudioSettings."""
    return _apply_indexed_update(
        settings, message, clear_cls=LabelsClear, update_cls=Label, field_name="labels"
    )


def apply_profile_message(settings: AudioSettings, message) -> AudioSettings:
    """Apply PROFILE or PROFILES_CLEAR messages to AudioSettings."""
    return _apply_indexed_update(
        settings,
        message,
        clear_cls=ProfilesClear,
        update_cls=Profile,
        field_name="profiles",
    )
